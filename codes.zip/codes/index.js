const express = require("express");
const path = require("path");
const fs = require("fs");

const app = express();
const port = 5000;

const folderPath = "/home/newuser002/Documents/force"; // Replace with the path to your folder

app.get("/", (req, res) => {
  // Read the contents of the folder
  fs.readdir(folderPath, (err, files) => {
    if (err) {
      console.error("Error reading files:", err);
      res.status(500).send("Internal Server Error");
    } else {
      // Filter only zip files
      const zipFiles = files.filter(
        (file) => path.extname(file).toLowerCase() === ".zip"
      );

      // Create an HTML list with download links
      const htmlList = zipFiles.map(
        (file) =>
          `<li><a href="/files/${encodeURIComponent(
            file
          )}" download>${file}</a></li>`
      );

      // Send the HTML response
      res.send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Zip File List</title>
        </head>
        <body>
          <h1>Zip File List</h1>
          <ul>${htmlList.join("")}</ul>
        </body>
        </html>
      `);
    }
  });
});

app.get("/files/:filename", (req, res) => {
  const { filename } = req.params;
  const filePath = path.join(folderPath, filename);

  // Check if the file exists
  fs.access(filePath, fs.constants.F_OK, (err) => {
    if (err) {
      console.error("Error accessing file:", err);
      res.status(404).send("File Not Found");
    } else {
      // Serve the file for download
      res.download(filePath, filename);
    }
  });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
